define([
  './alertSrv',
  './dashboard',
  './fields',
  './filterSrv',
  './kbnIndex',
  './querySrv',
  './timer',
  './panelMove',
  './solrSrv',
  './lucidworksSrv'
],
function () {});
